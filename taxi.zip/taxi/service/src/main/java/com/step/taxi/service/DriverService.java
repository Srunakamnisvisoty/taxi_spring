package com.step.taxi.service;

import com.step.taxi.dto.carDto.CarDto;
import com.step.taxi.dto.driverDto.DriverDto;
import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import com.step.taxi.dto.driverDto.DriverDtoWithId;

public interface DriverService extends CrudOperationService<DriverDtoWithDate> {

    DriverDtoWithId changeFullNameDriverById(Long id, String name, String lastName, String middleName);

    CarDto showCarByDriver(Long id);

    DriverDtoWithId changeDocumentData(Long id, String driversLicense, String passportData);

    DriverDto addNew(DriverDto driverDto);
}
