package com.step.taxi.mapper.uses;

import com.step.taxi.mapper.exception.DateTimeMapperException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.step.taxi.mapper.constants.Constants.DATE_TIME_PATTERN;

public class DateTimeMapper {

    public static String date(Date date) {
        if (date == null) {
            return null;
        }
        return new SimpleDateFormat(DATE_TIME_PATTERN).format(date);
    }

    public static Date date(String date) {
        if (date == null) {
            return null;
        }
        try {
            return new SimpleDateFormat(DATE_TIME_PATTERN).parse(date);
        } catch (ParseException exception) {
            exception.printStackTrace();
        }
        throw new DateTimeMapperException();
    }
}