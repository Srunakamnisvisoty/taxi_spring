package com.step.taxi.service.exeption;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.I_AM_A_TEAPOT)
@Getter
public class EntityIsNotCorrectException extends RuntimeException {

    public EntityIsNotCorrectException(String message) {
        super(message);
    }
}
