package com.step.taxi.service.impl;

import com.step.taxi.Car;
import com.step.taxi.CarRepository;
import com.step.taxi.Driver;
import com.step.taxi.DriverRepository;
import com.step.taxi.dto.carDto.CarDriverDto;
import com.step.taxi.dto.carDto.CarDto;
import com.step.taxi.dto.carDto.CarDtoWithIdAndDateAdded;
import com.step.taxi.dto.driverDto.DriverDto;
import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import com.step.taxi.dto.driverDto.DriverDtoWithId;
import com.step.taxi.mapper.CarMapper;
import com.step.taxi.mapper.DriverMapper;
import com.step.taxi.service.CarService;
import com.step.taxi.service.exeption.EntityIsNotCorrectException;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import javax.sound.midi.MidiChannel;
import javax.transaction.Transactional;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
@Transactional
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final DriverRepository driverRepository;
    private final CarMapper carMapper;
    private final DriverMapper driverMapper;

    @Override
    public List<CarDto> findByFuelConsumption(int fuelConsumption, Pageable pageable) {
        return convertList(carRepository.findAllByFuelConsumption(fuelConsumption, pageable));
    }

    @Override
    public List<CarDto> findByEquipment(String equipment, Pageable pageable) {
        return convertList(carRepository.findAllByEquipment(equipment, pageable));
    }

    @Override
    public int taxiFleetCost() {
        return carRepository.findAll().stream().mapToInt(Car::getPrice).sum();
    }

    @Override
    public void sortCarByFuelConsumption() {
        List<Car> carList = carRepository.findAll();
        carList.sort(Car::compareTo);
    }

    @Override
    public CarDriverDto setDriverForCar(Long idCar, Long driverId) {
        if (idCar > 0 && driverId > 0) {
            if (!carRepository.existsById(idCar)) {
                throw new EntityNotFoundException("Когда у тебя машины с таким id," +
                        " где-то в твоём таксопарке плачет один водила");
            }
            if (!driverRepository.existsById(driverId)) {
                throw new EntityNotFoundException("Когда у тебя водилы с таким id," +
                        " где-то в твоём таксопарке плачет одна машинка");
            }
            Driver driver = driverRepository.getById(driverId);
            CarDriverDto carDriverDto = carMapper.entityToCarDriverDto(carRepository.getById(idCar));
            driver.setDateAddedToCar(new Date());
            carDriverDto.getDriverList().add(driverMapper.entityToDtoWithDate(driver));
            return carMapper.entityToCarDriverDto(carRepository.save(carMapper.carDriverDtoToEntity(carDriverDto)));
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public List<CarDriverDto> showCarWithDrivers(Pageable pageable) {
        return carRepository.findAll().stream().
                map(carMapper::entityToCarDriverDto).collect(Collectors.toList());
    }

    @Override
    public List<DriverDtoWithDate> showDriversByCar(Long id) {
        if (id > 0) {
            if (carRepository.existsById(id)) {
                return carMapper.entityToCarDriverDto(carRepository.getById(id)).getDriverList();
            } else {
                throw new EntityNotFoundException("С таким id машины нет");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public CarDriverDto deleteDriverByCar(Long idCar, Long driverId) {
        if (idCar > 0 && driverId > 0) {
            if (carRepository.existsById(idCar)) {
                if (driverRepository.existsById(driverId)) {
                    Car car = carRepository.getById(idCar);
                    car.getDriverList().remove(driverRepository.getById(driverId));
                    return carMapper.entityToCarDriverDto(carRepository.save(car));
                } else {
                    throw new EntityNotFoundException("Водилы с таким id не нашли");
                }
            } else {
                throw new EntityNotFoundException("Машина с таким id ещё не выпустилась");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public CarDtoWithIdAndDateAdded changePrice(Long id, int price) {
        if (id > 0) {
            if (carRepository.existsById(id)) {
                if (price > 0) {
                    Car car = carRepository.getById(id);
                    car.setPrice(price);
                    return carMapper.entityToCarDtoWithId(carRepository.save(car));
                } else {
                    throw new IllegalArgumentException("Ты хочешь продать тачку ща бесплатно?");
                }
            } else {
                throw new EntityNotFoundException("Машина с таким id ещё не выпустилась");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public List<CarDtoWithIdAndDateAdded> all(Pageable pageable) {
        return convertListCarDtoWithId(carRepository.findAll());
    }

    @Override
    public CarDtoWithIdAndDateAdded findById(Long id) {
        if (id > 0) {
            if (carRepository.existsById(id)) {
                return carMapper.entityToCarDtoWithId(carRepository.getById(id));
            } else {
                throw new EntityNotFoundException("Машины с таким id нет, значит и искать тоже не буду");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public CarDto addNew(CarDto carDto) {
        if (carDto.getBrand().trim().length() == 0 ||
                carDto.getModel().trim().length() == 0 ||
                carDto.getEquipment().trim().length() == 0 ||
                carDto.getPrice() < 0 ||
                carDto.getAge() < 0 ||
                carDto.getFuelConsumption() < 0) {
            throw new EntityIsNotCorrectException("Фиаско братан, проверь введённые данные");
        } else {
            Car car = carMapper.carDtoToEntity(carDto);
            car.setDateAdded(new Date());
            return carMapper.entityToCarDto(carRepository.save(car));
        }
    }

    @Override
    public void delete(Long id) {
        if (id > 0) {
            if (carRepository.existsById(id)) {
                carRepository.deleteById(id);
            } else {
                throw new EntityNotFoundException("Машины с таким id нет, удалять нечего");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    private List<CarDtoWithIdAndDateAdded> convertListCarDtoWithId(List<Car> carList) {
        return carList.isEmpty() ?
                Collections.emptyList() :
                carList.stream().map(carMapper::entityToCarDtoWithId).collect(Collectors.toList());
    }

    private List<CarDto> convertList(List<Car> carList) {
        return carList.isEmpty() ?
                Collections.emptyList() :
                carList.stream().map(carMapper::entityToCarDtoWithId).collect(Collectors.toList());
    }
}
