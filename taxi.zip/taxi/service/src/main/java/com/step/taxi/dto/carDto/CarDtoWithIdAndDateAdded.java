package com.step.taxi.dto.carDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CarDtoWithIdAndDateAdded extends CarDto {

    @Schema(description = "Уникальный номер автомобиля в автопарке, заполянется атвоматически")
    private Long id;

    @Schema(description = "Дата добавления автомобиля в автопарк", example = "25.05.2022 15:20:34")
    private String dateAdded;
}
