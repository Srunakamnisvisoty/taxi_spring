package com.step.taxi.dto.driverDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.Date;

@Data
public class DriverDto {

    @Schema(description = "Имя водителя", example = "Магомед")
    private String name;

    @Schema(description = "Фамилия водителя", example = "Хайдурасимов")
    private String lastName;

    @Schema(description = "Отчество водителя", example = "Самвелович")
    private String middleName;

    @Schema(description = "Возраст водителя", example = "37")
    private int age;

    @Schema(description = "Серия и номер паспорта или вжн водителя", example = "HB2456789")
    private String passportData;

    @Schema(description = "Серия и номер водительского удостоверения водителя", example = "3BA 187945")
    private String driversLicense;

    @Schema(description = "Пол водителя", example = "мужской")
    private String gender;
}
