package com.step.taxi.dto.carDto;

import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class CarDriverDto extends CarDtoWithIdAndDateAdded {

    @Schema(description = "Список водителей, которые ездят на автомобиле")
    private List<DriverDtoWithDate> driverList;
}
