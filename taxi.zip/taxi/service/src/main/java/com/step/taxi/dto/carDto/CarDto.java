package com.step.taxi.dto.carDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CarDto {

    @Schema(description = "Наименования марки автомобиля", example = "BMW")
    private String brand;

    @Schema(description = "Модель автомобиля", example = "e60")
    private String model;

    @Schema(description = "Компектация автомобиля", example = "Lux")
    private String equipment;

    @Schema(description = "Расход топлива автомобиля", example = "10")
    private int fuelConsumption;

    @Schema(description = "Возвраст автомобиля", example = "15")
    private int age;

    @Schema(description = "Цена автомобиля", example = "10000")
    private int price;
}
