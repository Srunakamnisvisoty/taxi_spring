package com.step.taxi.service;

import com.step.taxi.dto.carDto.CarDriverDto;
import com.step.taxi.dto.carDto.CarDto;
import com.step.taxi.dto.driverDto.DriverDto;
import com.step.taxi.dto.carDto.CarDtoWithIdAndDateAdded;
import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CarService extends CrudOperationService<CarDtoWithIdAndDateAdded> {

    CarDto addNew(CarDto carDto);

    List<CarDto> findByFuelConsumption(int fuelConsumption, Pageable pageable);

    List<CarDto> findByEquipment(String equipment, Pageable pageable);

    int taxiFleetCost();

    void sortCarByFuelConsumption();

    CarDriverDto setDriverForCar(Long id, Long driverId);

    List<CarDriverDto> showCarWithDrivers(Pageable pageable);

    List<DriverDtoWithDate> showDriversByCar(Long id);

    CarDriverDto deleteDriverByCar(Long idCar, Long driverId);

    CarDtoWithIdAndDateAdded changePrice(Long id, int price);
}
