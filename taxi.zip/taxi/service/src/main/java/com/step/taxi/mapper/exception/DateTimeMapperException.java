package com.step.taxi.mapper.exception;

public class DateTimeMapperException extends RuntimeException {

    public DateTimeMapperException() {
        this("Не верный источник даты");
    }

    public DateTimeMapperException(String message) {
        super(message);
    }
}
