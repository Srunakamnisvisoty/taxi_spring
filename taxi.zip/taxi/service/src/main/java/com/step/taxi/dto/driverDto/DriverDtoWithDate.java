package com.step.taxi.dto.driverDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class DriverDtoWithDate extends DriverDtoWithId {

    @Schema(description = "Дата добавления водителя автомобилю", example = "25.05.2022 15:20:34")
    private String dateAddedToCar;
}
