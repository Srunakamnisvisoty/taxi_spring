package com.step.taxi.dto.driverDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class DriverDtoWithId extends DriverDto {

    @Schema(description = "Уникальный номер водителя, заполянется атвоматически")
    private Long id;

    @Schema(description = "Дата добавления трудоустройства водителя в таксопарк", example = "25.05.2022 15:20:34")
    private String dateOfEmployment;
}
