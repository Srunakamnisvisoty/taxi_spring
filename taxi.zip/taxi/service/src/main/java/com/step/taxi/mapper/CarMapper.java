package com.step.taxi.mapper;

import com.step.taxi.Car;
import com.step.taxi.dto.carDto.CarDriverDto;
import com.step.taxi.dto.carDto.CarDto;

import com.step.taxi.dto.carDto.CarDtoWithIdAndDateAdded;
import com.step.taxi.mapper.uses.DateTimeMapper;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {
        DateTimeMapper.class
})
public interface CarMapper {

    Car carDriverDtoToEntity(CarDriverDto carDriverDto);

    Car carDtoToEntity(CarDto carDto);

    CarDriverDto entityToCarDriverDto(Car car);

    CarDto entityToCarDto(Car car);

    CarDtoWithIdAndDateAdded entityToCarDtoWithId(Car car);

    CarDtoWithIdAndDateAdded carDtoWithIdToEntity(CarDtoWithIdAndDateAdded carDtoWithIdAndDateAdded);
}
