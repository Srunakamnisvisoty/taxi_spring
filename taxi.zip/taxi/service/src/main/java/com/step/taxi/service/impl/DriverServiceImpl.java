package com.step.taxi.service.impl;

import com.step.taxi.Car;
import com.step.taxi.CarRepository;
import com.step.taxi.Driver;
import com.step.taxi.DriverRepository;
import com.step.taxi.dto.carDto.CarDto;
import com.step.taxi.dto.driverDto.DriverDto;
import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import com.step.taxi.dto.driverDto.DriverDtoWithId;
import com.step.taxi.mapper.CarMapper;
import com.step.taxi.mapper.DriverMapper;
import com.step.taxi.service.DriverService;
import com.step.taxi.service.exeption.EntityIsNotCorrectException;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@AllArgsConstructor
@Service
@Transactional
public class DriverServiceImpl implements DriverService {

    private final DriverRepository driverRepository;
    private final DriverMapper driverMapper;
    private final CarRepository carRepository;
    private final CarMapper carMapper;

    @Override
    public List<DriverDtoWithDate> all(Pageable pageable) {
        List<DriverDtoWithDate> driverDtoList = new ArrayList<>();
        Page<Driver> page = driverRepository.findAll(pageable);
        for (Driver driver : page) {
            driverDtoList.add(driverMapper.entityToDtoWithDate(driver));
        }
        return driverDtoList;
    }

    @Override
    public DriverDtoWithDate findById(Long id) {
        if (id > 0) {
            if (driverRepository.existsById(id)) {
                return driverMapper.entityToDtoWithDate(driverRepository.getById(id));
            } else {
                throw new EntityNotFoundException("Не родился ещё тот Магомед, у корого есть такой id");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public DriverDto addNew(DriverDto driverDto) {
        if (driverDto.getName().length() == 0 ||
                driverDto.getLastName().length() == 0 ||
                driverDto.getAge() < 18 ||
                driverDto.getDriversLicense().length() == 0 ||
                driverDto.getPassportData().length() == 0) {
            throw new EntityIsNotCorrectException("Вроде всё так, но что-то не так, проверь ведённые данные");
        } else {
            Driver driver = driverMapper.dtoToEntity(driverDto);
            driver.setDateOfEmployment(new Date());
            driver.setDateAddedToCar(new Date());
            Driver saved = driverRepository.save(driver);
            return driverMapper.entityToDto(driverRepository.save(saved));
        }
    }

    @Override
    public DriverDtoWithId changeFullNameDriverById(Long id, String name, String lastName, String middleName) {
        if (id > 0) {
            if (driverRepository.existsById(id)) {
                Driver driver = driverRepository.getById(id);
                driver.setName(name);
                driver.setLastName(lastName);
                driver.setMiddleName(middleName);
                return driverMapper.entityToDtoWithId(driverRepository.save(driver));
            } else {
                throw new EntityNotFoundException("Мы очень пытались найти водителя с таким id, но мы все прос*али");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public void delete(Long id) {
        if (id > 0) {
            if (driverRepository.existsById(id)) {
                driverRepository.deleteById(id);
            } else {
                throw new EntityNotFoundException("Чё удалять, кали ничога няма с таким id");
            }
        } else {
            throw new IllegalArgumentException("Ну короче, id не может быть меньше нуля, и кстати равняться нулю тоже");
        }
    }

    @Override
    public CarDto showCarByDriver(Long id) {
        if (id > 0) {
            if (driverRepository.existsById(id)) {
                CarDto carDto = new CarDto();
                for (Car car : carRepository.findAll()) {
                    if (car.getDriverList().contains(driverRepository.getById(id))) {
                        carDto = carMapper.entityToCarDto(car);
                    }
                }
                return carDto;
            } else {
                throw new EntityNotFoundException("Нет водителя с таким Id");
            }
        } else {
            throw new IllegalArgumentException("Id не может быть меньше или равно нулю");
        }
    }

    @Override
    public DriverDtoWithId changeDocumentData(Long id, String driversLicense, String passportData) {
        if (id > 0) {
            if (driverRepository.existsById(id)) {
                Driver driver = driverRepository.getById(id);
                driver.setDriversLicense(driversLicense);
                driver.setPassportData(passportData);
                return driverMapper.entityToDtoWithId(driverRepository.save(driver));
            } else {
                throw new EntityNotFoundException("Нет водителя с таким Id");
            }
        } else {
            throw new IllegalArgumentException("Id не может быть меньше или равно нулю");
        }
    }
}
