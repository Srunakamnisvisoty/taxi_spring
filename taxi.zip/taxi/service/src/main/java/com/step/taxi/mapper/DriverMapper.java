package com.step.taxi.mapper;


import com.step.taxi.Driver;
import com.step.taxi.dto.driverDto.DriverDto;

import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import com.step.taxi.dto.driverDto.DriverDtoWithId;
import com.step.taxi.mapper.uses.DateTimeMapper;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {
        DateTimeMapper.class
})
public interface DriverMapper {

    Driver dtoToEntity(DriverDto driverDto);

    DriverDto entityToDto(Driver driver);

    DriverDtoWithId entityToDtoWithId(Driver driver);

    Driver dtoWithIdToEntity(DriverDtoWithId driverDtoWithId);

    DriverDtoWithDate entityToDtoWithDate(Driver driver);

    Driver dtoWithDateToEntity(DriverDtoWithDate driverDtoWithDate);


}
