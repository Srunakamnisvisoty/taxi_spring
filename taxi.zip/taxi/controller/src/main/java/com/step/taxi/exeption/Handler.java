package com.step.taxi.exeption;

import com.step.taxi.service.exeption.EntityIsNotCorrectException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.persistence.EntityNotFoundException;
import java.time.Instant;
import java.util.Date;

import static org.springframework.http.HttpStatus.I_AM_A_TEAPOT;

@RestControllerAdvice
public class Handler {

    @ExceptionHandler(EntityIsNotCorrectException.class)
    @ResponseStatus(I_AM_A_TEAPOT)
    public ErrorDetails handleEntityIsNotCorrect(EntityIsNotCorrectException entityIsNotCorrectException) {
        return ErrorDetails.builder().
                timestamp(Date.from(Instant.now())).
                message(entityIsNotCorrectException.getMessage()).
                httpStatus(I_AM_A_TEAPOT).
                details("Что-то не то ввёл, или кот пробежал по клаве").
                code(I_AM_A_TEAPOT.value()).
                build();
    }

    @ExceptionHandler(EntityNotFoundException.class)
    @ResponseStatus(I_AM_A_TEAPOT)
    public ErrorDetails handleEntityNotFoundException(EntityNotFoundException entityNotFoundException) {
        return  ErrorDetails.builder().
                timestamp(Date.from(Instant.now())).
                message(entityNotFoundException.getMessage()).
                httpStatus(I_AM_A_TEAPOT).
                details("Следующую строчку читай громко и с улыбкой на лице").
                code(I_AM_A_TEAPOT.value()).
                build();
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(I_AM_A_TEAPOT)
    public ErrorDetails handleIllegalArgumentException(IllegalArgumentException illegalArgumentException) {
        return  ErrorDetails.builder().
                timestamp(Date.from(Instant.now())).
                message(illegalArgumentException.getMessage()).
                httpStatus(I_AM_A_TEAPOT).
                details("Следующую строчку читай громко и с улыбкой на лице").
                code(I_AM_A_TEAPOT.value()).
                build();
    }
}
