package com.step.taxi;

import com.step.taxi.dto.carDto.CarDto;
import com.step.taxi.dto.driverDto.DriverDto;
import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import com.step.taxi.dto.driverDto.DriverDtoWithId;
import com.step.taxi.service.DriverService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api")
@Tag(name = "Водители автопарка", description = "Операции с водителями")
public class DriverController {

    private final DriverService driverService;

    @Operation(summary = "Показать список водителей", description = "Выводит на экран список всех водителей")
    @GetMapping("/drivers")
    public List<DriverDtoWithDate> findAllDriver(@RequestParam int page) {
        Pageable pageable = PageRequest.of(page, 5, Sort.by("id"));
        return driverService.all(pageable);
    }

    @Operation(summary = "Найти водителя по id", description = "Выводит на экран водителя по заданному id")
    @GetMapping("/drivers/findDriverById")
    public DriverDtoWithDate findDriverById(@RequestParam Long id) {
        return driverService.findById(id);
    }

    @Operation(summary = "Добавить нового водителя", description = "Добавляет нового водителя")
    @PutMapping("/drivers/saveDriver")
    public DriverDto addDriver(@RequestBody DriverDto driverDto) {
        return driverService.addNew(driverDto);
    }

    @Operation(summary = "Показать машину водителя", description = "Выводит на экран машину водителя по заданному id")
    @GetMapping("/drivers/showCarByDriver")
    public CarDto showCarByDriver(@RequestParam Long id) {
        return driverService.showCarByDriver(id);
    }

    @Operation(summary = "Изменить ФИО водителя", description = "Меняет ФИО водителя по задданому id")
    @PostMapping("/drivers/ChangeFullNameDriverById")
    public DriverDtoWithId changeFullName(@RequestParam Long id, String name, String lastName, String middleName) {
        return driverService.changeFullNameDriverById(id, name, lastName, middleName);
    }

    @Operation(summary = "Изменить документы водителя", description = "Меняет документы водителя по заданному id")
    @PostMapping("/drivers/changeDocumentDataDriverById")
    public DriverDtoWithId changeDocumentData(@RequestParam Long id, String driversLicense, String passportData) {
        return driverService.changeDocumentData(id, driversLicense, passportData);
    }

    @Operation(summary = "Уволить водителя", description = "Удаляет водителя по id")
    @DeleteMapping("/drivers/deleteDriverById")
    public void deleteDriverById(@RequestParam Long id) {
        driverService.delete(id);
    }
}
