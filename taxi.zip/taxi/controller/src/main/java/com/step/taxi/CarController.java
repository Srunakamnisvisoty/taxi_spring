package com.step.taxi;

import com.step.taxi.dto.carDto.CarDriverDto;
import com.step.taxi.dto.carDto.CarDto;
import com.step.taxi.dto.driverDto.DriverDto;
import com.step.taxi.dto.carDto.CarDtoWithIdAndDateAdded;
import com.step.taxi.dto.driverDto.DriverDtoWithDate;
import com.step.taxi.service.CarService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api")
@Tag(name = "Автопарк", description = "Операции с машинами")
public class CarController {

    private final CarService carService;

    @Operation(summary = "Показать список всех машин", description = "Выводит на экран список всех машин")
    @GetMapping("/cars")
    public List<CarDtoWithIdAndDateAdded> showAllCar(@RequestParam int page) {
        return carService.all(PageRequest.of(page, 5, Sort.by("id")));
    }

    @Operation(summary = "Найти машины по комплектации", description = "Выводить на экран список машин " +
            "соответствующие заданной комплектации")
    @GetMapping("/cars/carsByEquipment")
    public List<CarDto> findAllCarByEquipment(@RequestParam String equipment, int page){
        return carService.findByEquipment(equipment, PageRequest.of(page, 5, Sort.by("id")));
    }

    @Operation(summary = "Найти машины по расходу топлива", description = "Выводить на экран список машин " +
            "соответствующие заданному расходу топлива")
    @GetMapping("/cars/carsByFuelConsumption")
    public List<CarDto> findAllCarByFuelConsumption(@RequestParam int fuelConsumption, int page) {
        return carService.findByFuelConsumption(fuelConsumption, PageRequest.of(page, 5, Sort.by("id")));
    }

    @Operation(summary = "Найти машину по id", description = "Выводит на экран машину соответствующая заданному id")
    @GetMapping("/cars/carById")
    public CarDtoWithIdAndDateAdded findById(@RequestParam Long id) {
        return carService.findById(id);
    }

    @Operation(summary = "Стоимость таксопарка", description = "Выводит на экран стоимость автопарка")
    @GetMapping("/cars/taxiFleetCost")
    public int fleetCost() {
        return carService.taxiFleetCost();
    }

    @Operation(summary = "Добавить машину в таксопарк", description = "Добавляет новую машину в таксопарк")
    @PutMapping("/cars/saveCar")
    public CarDto addCar(@RequestBody CarDto carDto) {
        return carService.addNew(carDto);
    }

    @Operation(summary = "Отсортировать машины по расходу топлива", description = "Сортирует список машин" +
            " по расходу топлива")
    @PostMapping("/cars/sortByFuelConsumption")
    public void sortCarByFuelConsumption() {
        carService.sortCarByFuelConsumption();
    }

    @Operation(summary = "Добавить машине водителя", description = "Добавляет машине по заданному idCar" +
            " водителя по задонному driverId")
    @PostMapping("/cars/setDriverForCar")
    public CarDriverDto setDriverForCar(@RequestParam Long idCar, Long driverId) {
        return carService.setDriverForCar(idCar, driverId);
    }

    @Operation(summary = "Изменить стоимость автомобиля", description = "Меняет стоимость автомобиля")
    @PostMapping("/cars/changePriceCar")
    public CarDtoWithIdAndDateAdded changePrice(@RequestParam Long id, int price) {
        return carService.changePrice(id, price);
    }

    @Operation(summary = "Показать машины вместе с водителями", description = "Выводить на экран список всех машин" +
            " вместе с водителями")
    @GetMapping("/cars/showCarWithDrivers")
    public List<CarDriverDto> showCarWithDrivers(@RequestParam int page) {
        return carService.showCarWithDrivers(PageRequest.of(page, 5, Sort.by("id")));
    }

    @Operation(summary = "Показать водителей машины", description = "Выводить на экран список всех водителей" +
            " работающих на машине по заданному id")
    @GetMapping("/cars/showDriversByCar")
    public List<DriverDtoWithDate> showDriverByCar(@RequestParam Long id) {
        return carService.showDriversByCar(id);
    }

    @Operation(summary = "Удалить водителя из машины", description = "Удаляет водителя из машины по id")
    @DeleteMapping("/cars/deleteDriverByCar")
    public CarDriverDto deleteDriverByCar(@RequestParam Long idCar, Long driverId) {
        return carService.deleteDriverByCar(idCar, driverId);
    }

    @Operation(summary = "Удалить машину", description = "Удаляет машину в автопарке по заданному id")
    @DeleteMapping("/cars/deleteById")
    public void deleteById(@RequestParam Long id) {
        carService.delete(id);
    }
}
