SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `taxi`;
CREATE DATABASE `taxi` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `taxi`;

CREATE TABLE `car` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `age` int(11) NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `equipment` varchar(255) DEFAULT NULL,
  `fuel_consumption` int(11) NOT NULL,
  `model` varchar(255) DEFAULT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `car` (`id`, `age`, `brand`, `date_added`, `equipment`, `fuel_consumption`, `model`, `price`) VALUES
(1,	15,	'BMW',	'2022-05-26 09:03:20',	'Lux',	10,	'e60',	10000),
(2,	5,	'Volkswagen',	'2022-05-26 09:05:32',	'Classic',	8,	'Polo',	12000),
(3,	5,	'Lada',	'2022-05-26 09:06:35',	'Comfort',	7,	'Vesta',	11000),
(4,	3,	'Renault',	'2022-05-26 09:07:23',	'Classic',	7,	'Logan',	14000),
(5,	4,	'Kia',	'2022-05-26 09:10:01',	'Classic',	8,	'Rio',	12000);

CREATE TABLE `driver` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `age` int(11) NOT NULL,
  `date_added_to_car` datetime DEFAULT NULL,
  `date_of_employment` datetime DEFAULT NULL,
  `drivers_license` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `passport_data` varchar(255) DEFAULT NULL,
  `driver_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmhrgguwyjl5il8851w5lkph2v` (`driver_id`),
  CONSTRAINT `FKmhrgguwyjl5il8851w5lkph2v` FOREIGN KEY (`driver_id`) REFERENCES `car` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `driver` (`id`, `age`, `date_added_to_car`, `date_of_employment`, `drivers_license`, `gender`, `last_name`, `middle_name`, `name`, `passport_data`, `driver_id`) VALUES
(1,	37,	'2022-05-26 09:22:03',	'2022-05-26 09:11:30',	'3BA 187945',	'мужской',	'Хайдурасимов',	'Самвелович',	'Магомед',	'HB2456789',	1),
(2,	43,	'2022-05-26 09:23:57',	'2022-05-26 09:12:26',	'3ТA 178945',	'мужской',	'Бадулаев',	'Бадулаевич',	'Бадулай',	'HB2879546',	2),
(3,	32,	'2022-05-26 09:17:42',	'2022-05-26 09:13:27',	'3СA 157845',	'женский',	'Завьялова',	'Варфоломеевна',	'Ефрося',	'HB1456782',	3),
(4,	25,	'2022-05-26 09:17:45',	'2022-05-26 09:14:26',	'3ВУ 486135',	'мужской',	'Тики',	'Тави',	'Рики',	'РР5467895',	4),
(5,	23,	'2022-05-26 09:17:48',	'2022-05-26 09:15:43',	'3ВН 798546',	'мужской',	'Львинов',	'Симбович',	'Шерхан',	'РР5487954',	5);