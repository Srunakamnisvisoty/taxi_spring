package com.step.taxi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxiApplicationTests {

    @Test
    void contextLoads() {
    }

}
