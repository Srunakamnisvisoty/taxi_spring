package com.step.taxi;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Data
@Entity
@Table
public class Car implements Comparable<Car> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String brand;

    private String model;

    private String equipment;

    private int fuelConsumption;

    private int age;

    private int price;

    private Date dateAdded;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "driver_id")
    private List<Driver> driverList;

    @Override
    public int compareTo(Car car) {
        return fuelConsumption - car.getFuelConsumption();
    }
}

